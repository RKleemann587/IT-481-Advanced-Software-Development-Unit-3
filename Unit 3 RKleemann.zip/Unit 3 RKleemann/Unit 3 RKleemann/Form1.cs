﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Unit_3_RKleemann
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = (local); Initial Catalog = Northwind; Integrated Security = True";
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            UserName.Clear();
            PassWord.Clear();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source = (local); Initial Catalog = Northwind; Integrated Security = True";
                con.Open();
                SqlCommand com = new SqlCommand("Select * FROM dbo.Users Where UserName = @UserName and PassWord = @Password", con);
                com.Parameters.AddWithValue("@UserName", UserName.Text);
                com.Parameters.AddWithValue("@PassWord", PassWord.Text);
                SqlDataReader Dr = com.ExecuteReader();
                if(Dr.HasRows == true)
                    {
                        MessageBox.Show("Welcome!");
                    }
                else
                    {
                        MessageBox.Show("Check your Username or Password");
                    }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwindDataSet1.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter1.Fill(this.northwindDataSet1.Users);
            // TODO: This line of code loads data into the 'northwindDataSet.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.northwindDataSet.Users);

        }
    }
}
